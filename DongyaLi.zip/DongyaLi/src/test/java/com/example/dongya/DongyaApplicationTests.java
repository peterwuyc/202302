package com.example.dongya;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DongyaApplicationTests {

    @Test
    void contextLoads() {
    }

}
