package com.example.dongya.service;

import com.example.dongya.entity.Flight;
import com.example.dongya.entity.User;

import com.example.dongya.entity.request.UserRequestBody;

import java.util.List;

public interface FlightService {

    Flight getById(Integer id);

    void createFlight(UserRequestBody userRequestBody);

    List<Flight> getAll();

    List<Flight> getAllSorted();

    public String updateFlightStartTime(Integer id, String startTime);

    public List<Flight> getFlightByStartTime(String startTime);

    String deleteFlightById(Integer id);
    public void addUser(Integer FlightId, Integer UserId);
    public int setAvailableSeats(int id);
    int getAvailableSeats(int id);

    List<User> getAllUser(int id);
    public void save(Flight flight);


}
