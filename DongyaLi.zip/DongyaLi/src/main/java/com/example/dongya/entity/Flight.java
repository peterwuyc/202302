package com.example.dongya.entity;

import jakarta.persistence.*;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import com.example.dongya.entity.User;
@Table(name = "flight")
@Entity
public class Flight {

    @Id
    @Column
    private Integer id;
    @Column(nullable = false)
    private String flightNumber;
    @Column(nullable = false)
    private String start;
    @Column(nullable = false)
    private String destination;
    @Column
    private int availableSeats;


    @ManyToMany(cascade = {CascadeType.ALL})
    @JoinTable(name = "flight_User_mapping",
            joinColumns = @JoinColumn(name = "flight_id"),
            inverseJoinColumns = @JoinColumn(name = "user_id"))
    Set<User> users = new HashSet<>();

    public void setId(Integer id) {
        this.id = id;
    }

    public void setFlightNumber(String flightNumber) {
        this.flightNumber = flightNumber;
    }

    public void setStart(String start) {
        this.start = start;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }



    public void setUsers(Set<User> users) {
        this.users = users;
    }




    public String getFlightNumber() {
        return flightNumber;
    }

    public String getStart() {
        return start;
    }

    public String getDestination() {
        return destination;
    }



    public Set<User> getUsers() {
        return users;
    }

    public Integer getId() {
        return id;
    }

}
