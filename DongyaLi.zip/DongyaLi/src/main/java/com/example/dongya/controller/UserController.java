package com.example.dongya.controller;

import com.example.dongya.entity.User;
import com.example.dongya.entity.request.UserRequestBody;
import com.example.dongya.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController

public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping("/v1/User")
    public List<User> getAllUsers(){
        List<User> all = userService.getAllSorted();
        return all;
    }

    @GetMapping("/v1/User/sort")
    public List<User> getAllUserSorted(@RequestParam("sort")String sort){
        return userService.getAllSorted(sort);
    }

    @PostMapping("/v1/User")
    public String createOneUser(@RequestBody UserRequestBody userRequestBody){
        userService.createUser(userRequestBody);
        return "success!!!";
    }

    @PutMapping("/v1/user/{id}") //
    public String updateUserById(@PathVariable("id")Integer id,
                                    @RequestParam("email")String email){
        return userService.updateUserEmail(id,email);
    }

    @DeleteMapping("/v1/user/{id}")
    public String deleteUserById(@PathVariable("id")Integer id){
        return userService.deleteUserById(id);
    }


    @GetMapping("/v1/user/{id}")
    public User getById(@PathVariable("id")Integer id){
        return userService.getById(id);
    }

    @GetMapping("/v1/user/email/{email}")
    public User getById(@PathVariable("email")String email){
        return userService.getUserByEmail(email);
    }

}
