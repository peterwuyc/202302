package com.example.dongya.service;

import com.example.dongya.entity.User;
import com.example.dongya.entity.request.UserRequestBody;

import java.util.List;

public interface UserService {

    User getById(Integer id);

    void createUser(UserRequestBody userRequestBody);

    List<User> getAll();

    List<User> getAllSorted();

    List<User> getAllSorted(String sort); //overloading

    String updateUserEmail(Integer id, String email);

    String deleteUserById(Integer id);

    User getUserByEmail(String email);

    public User save(User user);

}
