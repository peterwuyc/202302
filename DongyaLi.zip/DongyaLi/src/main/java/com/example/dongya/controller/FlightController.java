package com.example.dongya.controller;

import com.example.dongya.entity.Flight;
import com.example.dongya.entity.User;
import com.example.dongya.repository.FlightRepository;
import com.example.dongya.service.FlightService;
import com.example.dongya.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.*;

@RestController
public class FlightController {

    @Autowired
    private FlightService flightService;

    @Autowired
    private UserService userService;


    @GetMapping("/v1/flight/{id}")
    public Flight getById(@PathVariable("id") Integer id) {
        return flightService.getById(id);
    }

    @PutMapping("/v1/flight")
    public String addUser(@RequestParam("flightId") Integer flightId,
                          @RequestParam("userId") Integer userId) {
        flightService.addUser(flightId, userId);
        return "success";
    }


    @GetMapping
    public List<Flight> getFlights() {
        return flightService.getAll();
    }

    @GetMapping("/{id}")
    public Flight getFlight(@PathVariable int id) {
        return flightService.getById(id);

    }

    @GetMapping("/{id}/seats")
    public Integer getAvailableSeats(@PathVariable int id) {

        return flightService.getAvailableSeats(id);
    }

    @PutMapping("/v1/flight/{flightId}")
    public String updateUserById(@PathVariable("flightId") Integer flightId,
                                 @RequestParam("startTime") String startTime) {
        return flightService.updateFlightStartTime(flightId, startTime);
    }

    @DeleteMapping("/v1/flight/{flightId}")
    public String deleteUserById(@PathVariable("flightId") Integer flightId) {
        return flightService.deleteFlightById(flightId);
    }

    @PostMapping("/{flightId,userID }/book")
    public ResponseEntity<String> bookAFlight(@PathVariable("flightId") int flightId, @PathVariable("userId") int userID) {
        Flight flight = flightService.getById(flightId);
        if (flight == null) {
            return new ResponseEntity<>("Flight not found", HttpStatus.NOT_FOUND);
        }
        if (flightService.getAvailableSeats(flightId) == 0) {
            return new ResponseEntity<>("No seats available for this flight", HttpStatus.BAD_REQUEST);
        }
        User user = userService.getById(userID);
        User savedUser = userService.save(user);
        if (savedUser == null) {
            return new ResponseEntity<>("Could not save user", HttpStatus.INTERNAL_SERVER_ERROR);
        }
        flightService.setAvailableSeats(flightService.getAvailableSeats(flightId) - 1);
        flightService.save(flight);
        return new ResponseEntity<>("Flight booked successfully", HttpStatus.OK);

    }

    @PostMapping("/{flightId, userId}/cancel")
    public ResponseEntity<String> cancelAFlight(@PathVariable("flightId") int flightId, @PathVariable("userId") int userID) {
        Flight flight = flightService.getById(flightId);
        if (flight == null) {
            return new ResponseEntity<>("Flight not found", HttpStatus.NOT_FOUND);
        }
        User savedUser = userService.getById(userID);
        if (savedUser == null) {
            return new ResponseEntity<>("User not found", HttpStatus.NOT_FOUND);
        }
        if (flightService.getAvailableSeats(flightId) == 10) {
            return new ResponseEntity<>("No seats have been booked for this flight", HttpStatus.BAD_REQUEST);
        }
        flightService.setAvailableSeats(flightService.getAvailableSeats(flightId) + 1);
        flightService.save(flight);
        userService.deleteUserById(userID);
        return new ResponseEntity<>("Flight cancelled successfully", HttpStatus.OK);
    }


}
