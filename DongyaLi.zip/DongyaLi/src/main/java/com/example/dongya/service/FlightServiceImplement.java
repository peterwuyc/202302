package com.example.dongya.service;

import com.example.dongya.entity.User;
import com.example.dongya.entity.Flight;
import com.example.dongya.entity.request.UserRequestBody;
import com.example.dongya.repository.UserRepository;
import com.example.dongya.repository.FlightRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class FlightServiceImplement implements FlightService{

    @Autowired
    private FlightRepository flightRepository;
    @Autowired
    private UserRepository userRepository;

    private static final int TOTALSEATS = 10;
    public Flight getById(Integer id) {
        Optional<Flight> flightOPT = flightRepository.findById(id);
        if (flightOPT.isPresent()) {
            return flightOPT.get();
        } else throw new RuntimeException("no such flight");
    }

    @Override
    public void addUser(Integer FlightId, Integer UserId) {
        Optional<Flight> flightOptional = flightRepository.findById(FlightId);
        if (flightOptional.isPresent()) {
            Flight flight = flightOptional.get();
            Set<User> users = flight.getUsers();
            Optional<User> userOpt = userRepository.findById(UserId);
            if (userOpt.isPresent()) {
                User user = userOpt.get();
                users.add(user);
            }
            flightRepository.save(flight);
        } else throw new RuntimeException("no such Flight");
    }


    @Override
    public void createFlight(UserRequestBody userRequestBody) {
        Flight flight = new Flight();
        BeanUtils.copyProperties(userRequestBody, flight);
        flight.setId((int) (Math.random() * 1000));
        flightRepository.save(flight);
    }

    @Override
    public List<Flight> getAll() {
        return flightRepository.findAll();
    }

    @Override
    public List<Flight> getAllSorted() {
        List<Flight> collect = flightRepository.findAll();
        Collections.sort(collect, (a, b) -> a.getId() - b.getId());
        return collect;
    }





    @Override
    public String updateFlightStartTime(Integer id, String startTime) {
        Optional<Flight> flight1 = flightRepository.findById(id);
        if (flight1.isPresent()) {
            Flight flight = flight1.get();
            flight.setStart(startTime);
            flightRepository.save(flight);
        }
        return "success";
    }

    @Override
    public String deleteFlightById(Integer id) {
        flightRepository.deleteById(id);
        return "success";
    }

    @Override
    public int getAvailableSeats(int id) {
        return TOTALSEATS - getAllUser(id).size();
    }

    @Override
    public int setAvailableSeats(int id) {
        return TOTALSEATS - getAllUser(id).size() -1;
    }

    @Override
    public List<User> getAllUser(int id) {
        return userRepository.findAll();
    }



    @Override
    public List<Flight> getFlightByStartTime(String startTime) {
        return flightRepository.getFightByStartTime(startTime);

    }

    @Override
    public void save(Flight flight){
        flightRepository.save(flight);
    }
}
