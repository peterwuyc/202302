package com.example.dongya.service;

import com.example.dongya.entity.User;
import com.example.dongya.entity.request.UserRequestBody;
import com.example.dongya.repository.UserRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service //
public class UserServiceImplement implements UserService {

    @Autowired
    private UserRepository repository;
    @Override
    public User getById(Integer id) {
        Optional<User> UserOptional= repository.findById(id);
        if(UserOptional.isPresent()){
            return UserOptional.get();
        }else throw new RuntimeException("no such user");
    }

    @Override
    public void createUser(UserRequestBody userRequestBody) {
        User user =new User();
        BeanUtils.copyProperties(userRequestBody, user);
        user.setId((int)(Math.random()*1000));
        repository.save(user);
    }

    @Override
    public List<User> getAll() {
        return repository.findAll();
    }

    @Override
    public List<User> getAllSorted() {
        return repository.findAllOrderByAgeAsc();
    }

    @Override
    public List<User> getAllSorted(String sort) {

        //sort -> age or email
        List<User> collect = repository.findAll()
                .stream()
                .sorted((s1, s2) -> {
                    if("age".equals(sort)){
                        return s1.getAge() - s2.getAge();
                    }else if("name".equals(sort)){
                        return s1.getName().compareTo(s2.getName());
                    }else return 0;
                }).collect(Collectors.toList());
        return collect;
    }

    @Override
    public String updateUserEmail(Integer id, String email) {
        Optional<User> user1=repository.findById(id);
        if(user1.isPresent()){
            User user =user1.get();
            user.setEmail(email);
            repository.save(user);
        }
        return "success";
    }

    @Override
    public String deleteUserById(Integer id) {
        repository.deleteById(id);
        return "success";
    }

    @Override
    public User getUserByEmail(String email) {
        return repository.getOneUserByEmail(email);

    }
    @Override
    public User save(User user){
        return repository.save(user);
    }

}
