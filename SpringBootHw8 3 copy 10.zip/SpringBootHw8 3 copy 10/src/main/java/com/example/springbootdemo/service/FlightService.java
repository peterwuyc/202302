package com.example.springbootdemo.service;

import com.example.springbootdemo.entity.Flight;
import com.example.springbootdemo.entity.User;
import com.example.springbootdemo.repostitory.JPAFlightRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class FlightService {

    @Autowired
    private JPAFlightRepository jpaFlightRepository;



    //list all flights
    public List<Flight> listAllFlight() {
        return jpaFlightRepository.findAll();
    }


    //get a flight by id
    public Flight getFlightById(String id) {
        Optional<Flight> load = jpaFlightRepository.findById(id);
        if (load.isPresent()) {
            return load.get();
        }
        return null;
    }

    //create a flight
    public void createFlight(Flight flight) {
        jpaFlightRepository.save(flight);
    }

    //delete a flight
    public void removeFlight(String id) {
        if (id == null) {
            System.out.println("Flight id is null !");
        }else {
            jpaFlightRepository.deleteById(id);
        }
    }

//    public void addStudent(Flight flight, Student student) {
//        jpaFlightRepository.addStudent(flight,student);
//    }

//    public List<Flight> listAllFlight(int page, int sizePerPage) {
//        Pageable pageable = PageRequest.of(page, sizePerPage, Sort.by("id"));
//        return jpaFlightRepository.listAllFlight(pageable);
//    }
}
