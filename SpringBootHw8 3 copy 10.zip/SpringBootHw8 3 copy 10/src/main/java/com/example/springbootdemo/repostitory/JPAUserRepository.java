package com.example.springbootdemo.repostitory;


import com.example.springbootdemo.entity.User;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface JPAUserRepository extends JpaRepository<User, String> {

    //List<User> findUserByName(String name);
    List<User> findUserByName(String name, Pageable pageable);

    //List<User> listAllUsers(Pageable pageable);

}
