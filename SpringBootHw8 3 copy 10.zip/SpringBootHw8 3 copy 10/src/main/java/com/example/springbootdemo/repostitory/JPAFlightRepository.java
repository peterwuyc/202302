package com.example.springbootdemo.repostitory;

import com.example.springbootdemo.entity.Flight;
import org.springframework.data.jpa.repository.JpaRepository;

public interface JPAFlightRepository extends JpaRepository<Flight, String> {

    //List<Teacher> listAllTeacher(Pageable pageable);

}
